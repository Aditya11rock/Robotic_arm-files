package com.example.robotic_arm;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Network;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.ArrayList;

import io.github.controlwear.virtual.joystick.android.JoystickView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    Button s_up,s_down,e_up,e_down,w_left,w_right,g_open,g_close,start_rec,recording,reset_btn;
    JoystickView joystickView;
    TextView textView;
    String prev="";

    public boolean rc=false;

    RequestQueue queue;

    public static ArrayList<ArrayList<Integer>> mad= new ArrayList<ArrayList<Integer>>();

    public ArrayList<Integer> lad=new ArrayList<>();

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

       // AndroidNetworking.initialize(getApplicationContext());

        s_up=findViewById(R.id.s_up);
        s_down=findViewById(R.id.s_down);
        e_up=findViewById(R.id.e_up);
        e_down=findViewById(R.id.e_down);
        w_left=findViewById(R.id.w_left);
        w_right=findViewById(R.id.w_right);
        g_open=findViewById(R.id.g_open);
        g_close=findViewById(R.id.g_close);
        recording=findViewById(R.id.recordings);
        reset_btn=findViewById(R.id.reset);

        /*
        reset_btn.setOnTouchListener(new View.OnTouchListener() {

            private Handler mHandler;

            @Override public boolean onTouch(View v, MotionEvent event) {
                switch(event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        if (mHandler != null) return true;
                        mHandler = new Handler();
                        mHandler.postDelayed(mAction, 300);
                        break;
                    case MotionEvent.ACTION_UP:
                        if (mHandler == null) return true;
                        mHandler.removeCallbacks(mAction);
                        mHandler = null;
                        break;
                }
                return false;
            }

            Runnable mAction = new Runnable() {
                @Override public void run() {
                   // System.out.println("Performing action...");
                    Log.d("continuous","function is being called");
                   String url="http://192.168.4.1/get?data=reset";
                   StringRequest stringRequest=new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {

                            Log.d("success",response);

                        }
                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {

                            Log.d("error",error.toString());

                        }
                    });

                    queue.add(stringRequest);
                    //Toast.makeText(getApplicationContext(), "reset done", Toast.LENGTH_SHORT).show();


                    mHandler.postDelayed(this, 300);
                }
            };

        });

        */
        /*
        s_up.setOnClickListener(this);
        s_down.setOnClickListener(this);
        e_up.setOnClickListener(this);
        e_down.setOnClickListener(this);
        w_left.setOnClickListener(this);
        w_right.setOnClickListener(this);
        g_open.setOnClickListener(this);
        g_close.setOnClickListener(this);
        reset_btn.setOnClickListener(this);
            */

        reset_btn.setOnClickListener(this);

        s_up.setOnTouchListener(new View.OnTouchListener() {

            private Handler mHandler;

            @Override public boolean onTouch(View v, MotionEvent event) {
                switch(event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        if (mHandler != null) return true;
                        mHandler = new Handler();
                        mHandler.postDelayed(mAction, 300);
                        break;
                    case MotionEvent.ACTION_UP:
                        if (mHandler == null) return true;
                        mHandler.removeCallbacks(mAction);
                        mHandler = null;
                        break;
                }
                return false;
            }

            Runnable mAction = new Runnable() {
                @Override public void run() {
                   // System.out.println("Performing action...");

                    if(rc)
                    {
                        if(lad.size()==0)
                        {
                            lad.add(0);
                        }
                        lad.add(7);
                    }

                    String url="http://192.168.4.1/get?data=shoulder_up";
                    StringRequest stringRequest=new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {

                            Log.d("success",response);

                        }
                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {

                            Log.d("error",error.toString());

                        }
                    });

                    queue.add(stringRequest);

                    mHandler.postDelayed(this, 300);
                }
            };

        });

        s_down.setOnTouchListener(new View.OnTouchListener() {

            private Handler mHandler;

            @Override public boolean onTouch(View v, MotionEvent event) {
                switch(event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        if (mHandler != null) return true;
                        mHandler = new Handler();
                        mHandler.postDelayed(mAction, 300);
                        break;
                    case MotionEvent.ACTION_UP:
                        if (mHandler == null) return true;
                        mHandler.removeCallbacks(mAction);
                        mHandler = null;
                        break;
                }
                return false;
            }

            Runnable mAction = new Runnable() {
                @Override public void run() {
                    //System.out.println("Performing action...");

                    if(rc)
                    {
                        if(lad.size()==0)
                        {
                            lad.add(0);
                        }
                        lad.add(8);
                    }

                   String url="http://192.168.4.1/get?data=shoulder_down";
                    StringRequest stringRequest2=new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {

                            Log.d("success",response);

                        }
                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {

                            Log.d("error",error.toString());

                        }
                    });

                    queue.add(stringRequest2);

                    mHandler.postDelayed(this, 300);
                }
            };

        });

        e_up.setOnTouchListener(new View.OnTouchListener() {

            private Handler mHandler;

            @Override public boolean onTouch(View v, MotionEvent event) {
                switch(event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        if (mHandler != null) return true;
                        mHandler = new Handler();
                        mHandler.postDelayed(mAction, 300);
                        break;
                    case MotionEvent.ACTION_UP:
                        if (mHandler == null) return true;
                        mHandler.removeCallbacks(mAction);
                        mHandler = null;
                        break;
                }
                return false;
            }

            Runnable mAction = new Runnable() {
                @Override public void run() {
                    //System.out.println("Performing action...");

                    if(rc)
                    {
                        if(lad.size()==0)
                        {
                            lad.add(0);
                        }
                        lad.add(5);
                    }
                   String url="http://192.168.4.1/get?data=elbow_up";
                    StringRequest stringRequest3=new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {

                            Log.d("success",response);

                        }
                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {

                            Log.d("error",error.toString());

                        }
                    });

                    queue.add(stringRequest3);

                    mHandler.postDelayed(this, 300);
                }
            };

        });

        e_down.setOnTouchListener(new View.OnTouchListener() {

            private Handler mHandler;

            @Override public boolean onTouch(View v, MotionEvent event) {
                switch(event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        if (mHandler != null) return true;
                        mHandler = new Handler();
                        mHandler.postDelayed(mAction, 300);
                        break;
                    case MotionEvent.ACTION_UP:
                        if (mHandler == null) return true;
                        mHandler.removeCallbacks(mAction);
                        mHandler = null;
                        break;
                }
                return false;
            }

            Runnable mAction = new Runnable() {
                @Override public void run() {
                   // System.out.println("Performing action...");

                    if(rc)
                    {
                        if(lad.size()==0)
                        {
                            lad.add(0);
                        }
                        lad.add(6);
                    }
                   String url="http://192.168.4.1/get?data=elbow_down";
                    StringRequest stringRequest4=new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {

                            Log.d("success",response);

                        }
                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {

                            Log.d("error",error.toString());

                        }
                    });

                    queue.add(stringRequest4);

                    mHandler.postDelayed(this, 300);
                }
            };

        });

        w_left.setOnTouchListener(new View.OnTouchListener() {

            private Handler mHandler;

            @Override public boolean onTouch(View v, MotionEvent event) {
                switch(event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        if (mHandler != null) return true;
                        mHandler = new Handler();
                        mHandler.postDelayed(mAction, 300);
                        break;
                    case MotionEvent.ACTION_UP:
                        if (mHandler == null) return true;
                        mHandler.removeCallbacks(mAction);
                        mHandler = null;
                        break;
                }
                return false;
            }

            Runnable mAction = new Runnable() {
                @Override public void run() {
                   // System.out.println("Performing action...");

                    if(rc)
                    {
                        if(lad.size()==0)
                        {
                            lad.add(0);
                        }
                        lad.add(3);
                    }
                   String url="http://192.168.4.1/get?data=Wrist_left";
                   StringRequest stringRequest=new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {

                            Log.d("success",response);

                        }
                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {

                            Log.d("error",error.toString());

                        }
                    });

                    queue.add(stringRequest);

                    mHandler.postDelayed(this, 300);
                }
            };

        });

        w_right.setOnTouchListener(new View.OnTouchListener() {

            private Handler mHandler;

            @Override public boolean onTouch(View v, MotionEvent event) {
                switch(event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        if (mHandler != null) return true;
                        mHandler = new Handler();
                        mHandler.postDelayed(mAction, 300);
                        break;
                    case MotionEvent.ACTION_UP:
                        if (mHandler == null) return true;
                        mHandler.removeCallbacks(mAction);
                        mHandler = null;
                        break;
                }
                return false;
            }

            Runnable mAction = new Runnable() {
                @Override public void run() {
                    //System.out.println("Performing action...");

                    if(rc)
                    {
                        if(lad.size()==0)
                        {
                            lad.add(0);
                        }
                        lad.add(4);
                    }

                   String url="http://192.168.4.1/get?data=Wrist_right";
                   StringRequest stringRequest=new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {

                            Log.d("success",response);

                        }
                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {

                            Log.d("error",error.toString());

                        }
                    });

                    queue.add(stringRequest);


                    mHandler.postDelayed(this, 300);
                }
            };

        });

        g_open.setOnTouchListener(new View.OnTouchListener() {

            private Handler mHandler;

            @Override public boolean onTouch(View v, MotionEvent event) {
                switch(event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        if (mHandler != null) return true;
                        mHandler = new Handler();
                        mHandler.postDelayed(mAction, 300);
                        break;
                    case MotionEvent.ACTION_UP:
                        if (mHandler == null) return true;
                        mHandler.removeCallbacks(mAction);
                        mHandler = null;
                        break;
                }
                return false;
            }

            Runnable mAction = new Runnable() {
                @Override public void run() {
                    //System.out.println("Performing action...");

                    if(rc)
                    {
                        if(lad.size()==0)
                        {
                            lad.add(0);
                        }
                        lad.add(1);
                    }

                   String url="http://192.168.4.1/get?data=gripper_open";
                   StringRequest stringRequest=new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {

                            Log.d("success",response);

                        }
                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {

                            Log.d("error",error.toString());

                        }
                    });

                    queue.add(stringRequest);

                    mHandler.postDelayed(this, 300);
                }
            };

        });

        g_close.setOnTouchListener(new View.OnTouchListener() {

            private Handler mHandler;

            @Override public boolean onTouch(View v, MotionEvent event) {
                switch(event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        if (mHandler != null) return true;
                        mHandler = new Handler();
                        mHandler.postDelayed(mAction, 300);
                        break;
                    case MotionEvent.ACTION_UP:
                        if (mHandler == null) return true;
                        mHandler.removeCallbacks(mAction);
                        mHandler = null;
                        break;
                }
                return false;
            }

            Runnable mAction = new Runnable() {
                @Override public void run() {
                    //System.out.println("Performing action...");

                    if(rc)
                    {
                        if(lad.size()==0)
                        {
                            lad.add(0);
                        }
                        lad.add(2);
                    }

                   String url="http://192.168.4.1/get?data=gripper_close";
                   StringRequest stringRequest=new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {

                            Log.d("success",response);

                        }
                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {

                            Log.d("error",error.toString());

                        }
                    });

                    queue.add(stringRequest);

                    mHandler.postDelayed(this, 300);
                }
            };

        });

        //recording buttons
        start_rec=findViewById(R.id.start_rec);


        start_rec.setOnClickListener(this);
        recording.setOnClickListener(this);

        queue= Volley.newRequestQueue(getApplicationContext());

        // joystick initialization
        joystickView=findViewById(R.id.joystick);
        joystickView.setOnMoveListener(new JoystickView.OnMoveListener() {
            @Override
            public void onMove(int angle, int strength) {

                Log.d("angle :", String.valueOf(angle));


                if(angle==0)
                {
                    if(!prev.equals("stop"))
                    {
                        String url="http://192.168.4.1/get?data=Stop";
                        StringRequest stringRequest=new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {

                                Log.d("success",response);

                            }
                        }, new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {

                                Log.d("error",error.toString());

                            }
                        });

                        queue.add(stringRequest);
                        prev="stop";
                    }
                }

                else if(angle>=45 && angle<=135)
                {
                    // textView.setText("Forward");
                   if(!prev.equals("forward"))
                   {
                       Log.d("working", "yup");
                       String url="http://192.168.4.1/get?data=Forward";
                       StringRequest stringRequest=new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                           @Override
                           public void onResponse(String response) {

                               Log.d("success",response);

                           }
                       }, new Response.ErrorListener() {
                           @Override
                           public void onErrorResponse(VolleyError error) {

                               Log.d("error",error.toString());

                           }
                       });

                       queue.add(stringRequest);
                       prev="forward";
                   }
                }
                else if(angle>=0 && angle<=45 || angle>=315 && angle<=360)
                {
                    //  textView.setText("Right");

                    if(!prev.equals("right"))
                    {
                        String url="http://192.168.4.1/get?data=Right";
                        StringRequest stringRequest=new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {

                                Log.d("success",response);

                            }
                        }, new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {

                                Log.d("error",error.toString());

                            }
                        });

                        queue.add(stringRequest);
                        prev="right";
                    }


                    Log.d("working", "yup");
                }
                else if(angle>=135 && angle<=225)
                {
                    // textView.setText("Left");
                    if(!prev.equals("left"))
                    {
                        String url="http://192.168.4.1/get?data=Left";
                        StringRequest stringRequest=new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {

                                Log.d("success",response);

                            }
                        }, new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {

                                Log.d("error",error.toString());

                            }
                        });

                        queue.add(stringRequest);
                        prev="left";
                    }

                    Log.d("working", "yup");
                }
                else if(angle>=225 && angle<=315)
                {
                    // textView.setText("Backward");
                    if(!prev.equals("backward"))
                    {
                        String url="http://192.168.4.1/get?data=Backward";
                        StringRequest stringRequest=new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {

                                Log.d("success",response);

                            }
                        }, new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {

                                Log.d("error",error.toString());

                            }
                        });

                        queue.add(stringRequest);
                        prev="backward";
                    }

                    Log.d("working", "yup");
                }


            }
        });


    }

    @Override
    public void onClick(View v) {

        switch (v.getId())
        {
            /*   case R.id.s_up:
                if(rc)
                {
                    if(lad.size()==0)
                    {
                        lad.add(0);
                    }
                    lad.add(7);
                }

                String url="http://192.168.4.1/get?data=shoulder_up";
                StringRequest stringRequest=new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                            Log.d("success",response);

                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                        Log.d("error",error.toString());

                    }
                });

                queue.add(stringRequest);
                //Toast.makeText(getApplicationContext(), "Shoulder Up", Toast.LENGTH_SHORT).show();
                break;
            case R.id.s_down:

                if(rc)
                {
                    if(lad.size()==0)
                    {
                        lad.add(0);
                    }
                    lad.add(8);
                }

                 url="http://192.168.4.1/get?data=shoulder_down";
                StringRequest stringRequest2=new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        Log.d("success",response);

                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                        Log.d("error",error.toString());

                    }
                });

                queue.add(stringRequest2);
               // Toast.makeText(getApplicationContext(), "Shoulder Down", Toast.LENGTH_SHORT).show();
                break;
            case R.id.e_up:
                if(rc)
                {
                    if(lad.size()==0)
                    {
                        lad.add(0);
                    }
                    lad.add(5);
                }
                url="http://192.168.4.1/get?data=elbow_up";
                StringRequest stringRequest3=new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        Log.d("success",response);

                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                        Log.d("error",error.toString());

                    }
                });

                queue.add(stringRequest3);
              //  Toast.makeText(getApplicationContext(), "Elbow Up", Toast.LENGTH_SHORT).show();
                break;
            case R.id.e_down:
                if(rc)
                {
                    if(lad.size()==0)
                    {
                        lad.add(0);
                    }
                    lad.add(6);
                }
                 url="http://192.168.4.1/get?data=elbow_down";
                StringRequest stringRequest4=new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        Log.d("success",response);

                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                        Log.d("error",error.toString());

                    }
                });

                queue.add(stringRequest4);
             //   Toast.makeText(getApplicationContext(), "Elbow Down", Toast.LENGTH_SHORT).show();
                break;
            case R.id.w_left:
                if(rc)
                {
                    if(lad.size()==0)
                    {
                        lad.add(0);
                    }
                    lad.add(3);
                }
                 url="http://192.168.4.1/get?data=Wrist_left";
                 stringRequest=new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        Log.d("success",response);

                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                        Log.d("error",error.toString());

                    }
                });

                queue.add(stringRequest);
             //   Toast.makeText(getApplicationContext(), "Wrist left", Toast.LENGTH_SHORT).show();
                break;
            case R.id.w_right:

                if(rc)
                {
                    if(lad.size()==0)
                    {
                        lad.add(0);
                    }
                    lad.add(4);
                }

                url="http://192.168.4.1/get?data=Wrist_right";
                stringRequest=new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        Log.d("success",response);

                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                        Log.d("error",error.toString());

                    }
                });

                queue.add(stringRequest);
            //    Toast.makeText(getApplicationContext(), "Wrist Right", Toast.LENGTH_SHORT).show();
                break;
            case R.id.g_open:

                if(rc)
                {
                    if(lad.size()==0)
                    {
                        lad.add(0);
                    }
                    lad.add(1);
                }

                url="http://192.168.4.1/get?data=gripper_open";
                stringRequest=new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        Log.d("success",response);

                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                        Log.d("error",error.toString());

                    }
                });

                queue.add(stringRequest);
             //   Toast.makeText(getApplicationContext(), "Gripper Open", Toast.LENGTH_SHORT).show();
                break;
            case R.id.g_close:

                if(rc)
                {
                    if(lad.size()==0)
                    {
                        lad.add(0);
                    }
                    lad.add(2);
                }

                url="http://192.168.4.1/get?data=gripper_close";
                stringRequest=new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        Log.d("success",response);

                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                        Log.d("error",error.toString());

                    }
                });

                queue.add(stringRequest);
            //    Toast.makeText(getApplicationContext(), "Gripper Close", Toast.LENGTH_SHORT).show();
                break;

     */
            case R.id.start_rec:
                if(rc==false)
                {
                    rc=true;
                    lad.clear();
                    start_rec.setText("stop_rec");
                    start_rec.setBackgroundResource(R.drawable.recstarted);

                }
                else {
                    if(lad.size()>0)
                    {
                        mad.add(lad);
                    }
                    rc=false;
                    start_rec.setText("start_rec");
                    start_rec.setBackgroundResource(R.drawable.button_pressed);
                }
               // Toast.makeText(getApplicationContext(), "recording started", Toast.LENGTH_SHORT).show();
                break;
            case R.id.recordings:

                /*
                for(int i=0;i<mad.size();i++)
                {
                    for(int j=0;j<mad.get(i).size();j++)
                    {
                        Log.d(Integer.toString(mad.get(i).get(j)),Integer.toString(i));
                    }

                }
                */

                Intent intent=new Intent(getApplicationContext(),Recodings_display.class);
                startActivity(intent);
                break;
            case R.id.reset:
               String url="http://192.168.4.1/get?data=reset";
               StringRequest stringRequest=new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        Log.d("success",response);

                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                        Log.d("error",error.toString());

                    }
                });

                queue.add(stringRequest);
                Toast.makeText(getApplicationContext(), "reset done", Toast.LENGTH_SHORT).show();

        }



    }


}