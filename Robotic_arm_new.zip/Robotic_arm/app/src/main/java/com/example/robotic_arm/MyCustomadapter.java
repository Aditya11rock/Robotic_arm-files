package com.example.robotic_arm;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.ArrayList;

public class MyCustomadapter extends RecyclerView.Adapter<MyCustomadapter.ViewHolder> {

    ArrayList<ArrayList<Integer>> lad;
    Context context;
    RequestQueue queue;


    public MyCustomadapter(Context context, ArrayList<ArrayList<Integer>> lad) {
        this.lad = lad;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        Context con= parent.getContext();
        LayoutInflater inflater=LayoutInflater.from(con);
        View view=inflater.inflate(R.layout.customlayoutfor,parent,false);
        ViewHolder viewHolder= new ViewHolder(view);


        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        String name="rec_no "+Integer.toString(position+1);
        holder.textView.setText(name);
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Toast.makeText(context.getApplicationContext(), "Position "+Integer.toString(holder.getAdapterPosition()),Toast.LENGTH_SHORT).show();
                Thread thread=new Thread(){

                    @Override
                    public void run() {

                        ArrayList<Integer> bad= lad.get(holder.getAdapterPosition());
                        queue= Volley.newRequestQueue(context.getApplicationContext());
                        for(int i=0;i<bad.size();i++)
                        {
                            int val=bad.get(i);
                            switch (val)
                            {
                                case 0:
                                    String url="http://192.168.4.1/get?data=reset";
                                    StringRequest stringRequest=new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                                        @Override
                                        public void onResponse(String response) {

                                            Log.d("success",response);

                                        }
                                    }, new Response.ErrorListener() {
                                        @Override
                                        public void onErrorResponse(VolleyError error) {

                                            Log.d("error",error.toString());

                                        }
                                    });

                                    try {
                                        queue.add(stringRequest);
                                        sleep(500);
                                    }catch (InterruptedException exception){
                                        exception.printStackTrace();
                                    }

                                    break;
                                case 1:
                                    url="http://192.168.4.1/get?data=gripper_open";
                                    stringRequest=new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                                        @Override
                                        public void onResponse(String response) {

                                            Log.d("success",response);

                                        }
                                    }, new Response.ErrorListener() {
                                        @Override
                                        public void onErrorResponse(VolleyError error) {

                                            Log.d("error",error.toString());

                                        }
                                    });

                                    try {
                                        queue.add(stringRequest);
                                        sleep(500);
                                    }catch (InterruptedException exception){
                                        exception.printStackTrace();
                                    }

                                    break;
                                case 2:
                                    url="http://192.168.4.1/get?data=gripper_close";
                                    stringRequest=new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                                        @Override
                                        public void onResponse(String response) {

                                            Log.d("success",response);

                                        }
                                    }, new Response.ErrorListener() {
                                        @Override
                                        public void onErrorResponse(VolleyError error) {

                                            Log.d("error",error.toString());

                                        }
                                    });

                                    queue.add(stringRequest);
                                    break;
                                case 3:
                                    url="http://192.168.4.1/get?data=Wrist_left";
                                    stringRequest=new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                                        @Override
                                        public void onResponse(String response) {

                                            Log.d("success",response);

                                        }
                                    }, new Response.ErrorListener() {
                                        @Override
                                        public void onErrorResponse(VolleyError error) {

                                            Log.d("error",error.toString());

                                        }
                                    });

                                    try {
                                        queue.add(stringRequest);
                                        sleep(500);
                                    }catch (InterruptedException exception){
                                        exception.printStackTrace();
                                    }


                                    break;
                                case 4:
                                    url="http://192.168.4.1/get?data=Wrist_right";
                                    stringRequest=new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                                        @Override
                                        public void onResponse(String response) {

                                            Log.d("success",response);

                                        }
                                    }, new Response.ErrorListener() {
                                        @Override
                                        public void onErrorResponse(VolleyError error) {

                                            Log.d("error",error.toString());

                                        }
                                    });

                                    try {
                                        queue.add(stringRequest);
                                        sleep(500);
                                    }catch (InterruptedException exception){
                                        exception.printStackTrace();
                                    }


                                    break;
                                case 5:
                                    url="http://192.168.4.1/get?data=elbow_up";
                                    stringRequest=new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                                        @Override
                                        public void onResponse(String response) {

                                            Log.d("success",response);

                                        }
                                    }, new Response.ErrorListener() {
                                        @Override
                                        public void onErrorResponse(VolleyError error) {

                                            Log.d("error",error.toString());

                                        }
                                    });

                                    try {
                                        queue.add(stringRequest);
                                        sleep(500);
                                    }catch (InterruptedException exception){
                                        exception.printStackTrace();
                                    }


                                    break;
                                case 6:
                                    url="http://192.168.4.1/get?data=elbow_down";
                                    stringRequest=new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                                        @Override
                                        public void onResponse(String response) {

                                            Log.d("success",response);

                                        }
                                    }, new Response.ErrorListener() {
                                        @Override
                                        public void onErrorResponse(VolleyError error) {

                                            Log.d("error",error.toString());

                                        }
                                    });

                                    try {
                                        queue.add(stringRequest);
                                        sleep(500);
                                    }catch (InterruptedException exception){
                                        exception.printStackTrace();
                                    }


                                    break;
                                case 7:
                                    url="http://192.168.4.1/get?data=shoulder_up";
                                    stringRequest=new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                                        @Override
                                        public void onResponse(String response) {

                                            Log.d("success",response);

                                        }
                                    }, new Response.ErrorListener() {
                                        @Override
                                        public void onErrorResponse(VolleyError error) {

                                            Log.d("error",error.toString());

                                        }
                                    });

                                    try {
                                        queue.add(stringRequest);
                                        sleep(500);
                                    }catch (InterruptedException exception){
                                        exception.printStackTrace();
                                    }


                                    break;
                                case 8:
                                    url="http://192.168.4.1/get?data=shoulder_down";
                                    stringRequest=new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                                        @Override
                                        public void onResponse(String response) {

                                            Log.d("success",response);

                                        }
                                    }, new Response.ErrorListener() {
                                        @Override
                                        public void onErrorResponse(VolleyError error) {

                                            Log.d("error",error.toString());

                                        }
                                    });

                                    try {
                                        queue.add(stringRequest);
                                        sleep(500);
                                    }catch (InterruptedException exception){
                                        exception.printStackTrace();
                                    }


                                    break;

                            }
                        }

                    }
                };

                thread.start();

            }
        });

    }

    @Override
    public int getItemCount() {
        return lad.size();
    }



    public static class ViewHolder extends RecyclerView.ViewHolder {

        TextView textView;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            textView=itemView.findViewById(R.id.nameoffile);
        }
    }
}
