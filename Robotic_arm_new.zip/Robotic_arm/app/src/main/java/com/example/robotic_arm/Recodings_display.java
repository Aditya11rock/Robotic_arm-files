package com.example.robotic_arm;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.TextView;

public class Recodings_display extends AppCompatActivity {


    TextView textView;
    RecyclerView recyclerView;
    MyCustomadapter myCustomadapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recodings_display);

        textView=findViewById(R.id.rec_count);
        if(MainActivity.mad.size()>0)
        {
            String s=Integer.toString(MainActivity.mad.size())+" recording available";
            textView.setText(s);
        }

        recyclerView=findViewById(R.id.display);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        myCustomadapter=new MyCustomadapter(getApplicationContext(),MainActivity.mad);
        recyclerView.setAdapter(myCustomadapter);



    }
}